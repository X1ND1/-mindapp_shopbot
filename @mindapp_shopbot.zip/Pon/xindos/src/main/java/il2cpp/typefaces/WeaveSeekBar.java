package il2cpp.typefaces;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.SeekBar.OnSeekBarChangeListener;
import il2cpp.Utils;

public class WeaveSeekBar extends LinearLayout {
	Context context;
	
	public LinearLayout topLine, bottomLine;
	public TextView title, valueText;
	
	public SeekBar slider;
	
	public int max, current, value;
	public Callback callback;
	public int mainColor = 0;
	
	public static interface Callback {
		public void onChange(int value);
	}
	
	public void setCallback(Callback call) {
		callback = call;
	}
	
	public void setValue(int val) {
		if (val > max) val = max;
		if (val < 0) val = 0;
		
		value = val;
		valueText.setText(Integer.toString(value));
		slider.setProgress(value);
		if (callback != null) callback.onChange(value);
	}
	
	public WeaveSeekBar(Context ctx, String name, int max1, int current1) {
		super(ctx);
		context = ctx;
		
		{ // Other
			max = max1;
			current = current1;
			value = current;
		}
		
		mainColor = Color.parseColor("#FFD12B59");
		setOrientation(LinearLayout.VERTICAL);
		
		bottomLine = new LinearLayout(context);
		{ // Bottom line (Decrease, Slider, Increase)
			bottomLine.setOrientation(LinearLayout.HORIZONTAL);
			
			slider = new SeekBar(context);
			{ // Slider
				//slider.setPadding(15,0,15,0);
				GradientDrawable thumbr = new GradientDrawable();
				thumbr.setColor(Color.WHITE);
				thumbr.setCornerRadius(1);
				thumbr.setBounds(1,1,1,1);
				thumbr.setSize(200, 25);
				//slider.setBackground(thumbr);
				slider.setMax(max);
				slider.setProgress(current);
				GradientDrawable thumb = new GradientDrawable();
				thumb.setColor(mainColor);
				thumb.setStroke(2, Color.parseColor("#FFD12B59"));
				thumb.setSize(16,16);
				thumb.setCornerRadius(2);
				//thumb.setPadding(40, 40, 40, 40);
				
				thumb.setTintMode(PorterDuff.Mode.MULTIPLY);

				slider.setThumb(thumb);
				
				slider.getProgressDrawable().setColorFilter(mainColor, PorterDuff.Mode.MULTIPLY);
				
				{
					slider.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
						@Override
						public void onProgressChanged(SeekBar sl, int v, boolean b) {
							setValue(v);
						}
						
						@Override
						public void onStopTrackingTouch(SeekBar sl) {}
						@Override
						public void onStartTrackingTouch(SeekBar sl) {}
					});
				}
			}
			
			bottomLine.setPadding(5, 0, 0, 0);
			
			title = new TextView(context);
			{ // Title slider
				title.setText(name);
				title.setTextSize(10.5f);
				title.setTypeface(Utils.font(context));
				title.setTextColor(Color.WHITE);
				title.setGravity(Gravity.CENTER_VERTICAL);
				title.setPadding(10,0,0,0);
			}

			valueText = new TextView(context);
			{ // Value text (right title)
				valueText.setText(Integer.toString(current));
				valueText.setTextSize(10.5f);
				valueText.setTypeface(Utils.font(context));
				valueText.setTextColor(Color.WHITE);
				valueText.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
				valueText.setPadding(0,0,0,0);
			}
		    bottomLine.addView(title, new LayoutParams(-1, -1));
			bottomLine.addView(slider, new LayoutParams(Utils.dp(context, 80), -1));
			bottomLine.addView(valueText, -1, -1);
		}
		
		setLayoutParams(new LinearLayout.LayoutParams(-2, Utils.dp(context, 20)));
		addView(bottomLine, -2,-1);
	}
}
