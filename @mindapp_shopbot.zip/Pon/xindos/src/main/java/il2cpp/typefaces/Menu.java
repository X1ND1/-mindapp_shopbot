package il2cpp.typefaces;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.inputmethod.InputMethodManager;
import il2cpp.*;
import android.text.*;
import android.view.Window.*; 
import android.text.method.*;
import android.graphics.Typeface;
import android.util.*;
import android.view.*;
import android.widget.*;
import android.view.animation.AlphaAnimation; 
import android.view.animation.Animation;
import java.io.*;
import java.util.Objects;
import android.widget.LinearLayout.LayoutParams;
import java.util.ArrayList;
import android.view.View.OnClickListener;
import il2cpp.typefaces.*;


public class Menu
{
	protected int WIDTH,HEIGHT;
    
	public Typeface google(Context yes) {return Typeface.createFromAsset(yes.getAssets(), "Font.ttf");}
	
	protected Context context;
	protected FrameLayout _parentBox;
	protected LinearLayout __page;
	protected ScrollView __scroll;
	
	public ArrayList<PageButton> _pagebuttons = new ArrayList<>();
	public ArrayList<LinearLayout> __pages = new ArrayList<>();
	public ArrayList<ArrayList<UnderPageButton>> __underspage = new ArrayList<>();
	
	public ArrayList<ComponentBlock> blocks = new ArrayList<>();
	
	public ImageView _icon;
	public TextView __pagetitle;
	public ImageView __pagesrc;
	boolean _isShow = false;
	
	LinearLayout menulayout,linear15,linear17,linear18,_pages,_close,linear16,linear23,_underpages,_scroll;
TextView textview22;
ImageView imageview21;
 
	protected WindowManager wmManager;
	protected WindowManager.LayoutParams wmParams;
	
	protected void init(Context context) {
		
		this.context = context;
		
		_parentBox = new FrameLayout(context);

		_parentBox.setOnTouchListener(handleMotionTouch);
		wmManager = ((Activity)context).getWindowManager();
		int aditionalFlags=0;
		if (Build.VERSION.SDK_INT >= 11)
			aditionalFlags = WindowManager.LayoutParams.FLAG_SPLIT_TOUCH;
		if (Build.VERSION.SDK_INT >=  3)
			aditionalFlags = aditionalFlags | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM;
		wmParams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			0,//initialX
			0,//initialy
			WindowManager.LayoutParams.TYPE_APPLICATION,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
			aditionalFlags,
			PixelFormat.TRANSPARENT
		);
		wmParams.gravity = Gravity.CENTER;
	}
	
	public int dpi(float dp) {
		float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
	}
	
	public void showMenu() {
		_isShow = true;
		_parentBox.removeAllViews();
		_parentBox.addView(menulayout);
		ObjectAnimator scaleDown = ObjectAnimator.ofPropertyValuesHolder(menulayout, 
																		 PropertyValuesHolder.ofFloat("scaleX", 0f, 1.0f),
																		 PropertyValuesHolder.ofFloat("scaleY", 0f, 1.0f));															 PropertyValuesHolder.ofFloat("scaleY", 0f, 1.0f);
		scaleDown.setDuration(350);
		scaleDown.start();
	}

	public void hideMenu() {
		_isShow = false;
		ObjectAnimator scaleDown = ObjectAnimator.ofPropertyValuesHolder(menulayout, 
																		 PropertyValuesHolder.ofFloat("scaleX", 1.0f, 0f),
																		 PropertyValuesHolder.ofFloat("scaleY", 1.0f, 0f));
		scaleDown.setDuration(350);
		scaleDown.start();
		new Handler().postDelayed(new Runnable() {
			public void run() {
				_parentBox.removeAllViews();
				_parentBox.addView(_icon, dpi(50), dpi(50));
				Utils.anim(_icon, 200);
			}
		}, 350);
	}
	
	public void newPage(final String nm, final String src, final String[] split) {
		final PageButton _butt = new PageButton(context, nm, src);
		
		final int underid = __underspage.size();
		ArrayList<UnderPageButton> unds = new ArrayList<>();
		__underspage.add(unds);
		final int id = _pagebuttons.size();
		for (int i = 3; i < split.length; i++) {
			newUnders(split[i].split(","), underid);
		}
		
		_butt.callback = new PageButton.Callback() {
			public void onClick() {
				__pagetitle.setText(nm);
				Utils.SetAssets(context, __pagesrc, src);
				showUnder(underid);
				for (PageButton _p: _pagebuttons) {
					_p.hide();
				}
				_butt.show();
			}
		};
		
		_pages.addView(_butt);
	}
	
	public void showUnder(int id) {
		for (final ArrayList<UnderPageButton> under: __underspage) {
			for (UnderPageButton _und: under) {
				_und.setVisibility(View.GONE);
			}
		}
		for (UnderPageButton unds: __underspage.get(id)) {
			unds.setVisibility(View.VISIBLE);
		}
	}
	
	public void newUnders(String[] text, final int id) {
		if (true) {
			final String name = text[0].trim();
			final String src = text[1].trim();
			
			LinearLayout _page = new LinearLayout(context);
			
			final int pageid = __pages.size();
			__page.setOrientation(LinearLayout.VERTICAL);
			_page.setOrientation(LinearLayout.VERTICAL);
			__page.addView(_page, -1, -1);
			_page.setVisibility(View.GONE);
			__pages.add(_page);
			
			final UnderPageButton _butt = new UnderPageButton(context, name, src);
			_butt.callback = new UnderPageButton.Callback() {
				public void onClick() {
					showPage(pageid);
					for (UnderPageButton _p: __underspage.get(id)) {
						_p.hide();
					}
					_butt.show();
				}
			};
			_butt.setVisibility(View.GONE);
			__underspage.get(id).add(_butt);
			_underpages.addView(_butt);
		}
	}
	
	public void showPage(final int id) {
		for (LinearLayout layout: __pages) {
			layout.setVisibility(View.GONE);
		}
		__pages.get(id).setVisibility(View.VISIBLE);
		Utils.anim(__pages.get(id), 400);
	}
	
	public int newBlock(int pageid, String[] names) {
		final int blockid = blocks.size();

		LinearLayout blockline = new LinearLayout(context);
		blockline.setOrientation(LinearLayout.HORIZONTAL);

		for (int i = 0; i < names.length; i++) {
			String name = names[i];
			ComponentBlock block = new ComponentBlock(context, name);
			blocks.add(block);

			if (names.length > 1) {
				if ((i != 0)) {
					LinearLayout expand = new LinearLayout(context);
					blockline.addView(expand, dpi(5), -1);
				}
			}
			blockline.addView(block, new LinearLayout.LayoutParams(-1, -1, 1));

		}
		__pages.get(pageid).addView(blockline, -1, -1);
		return blockid;
	}
	
	public Menu(Context context)
	{
		init(context);
		
		_icon = new ImageView(context);
		Utils.SetAssets(context, _icon, "icon.png");
		
		menulayout = new LinearLayout(context);
				{
					menulayout.setOrientation(0);
					menulayout.setPadding(5, 5, 5, 5);
					menulayout.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16777216);
					menulayout.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(1100, 825, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					menulayout.setLayoutParams(lp);
				}

		linear15 = new LinearLayout(context);
				{
					linear15.setOrientation(1);
					linear15.setPadding(5, 5, 5, 5);
					linear15.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(-14277334);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(1, -16777216);
					linear15.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(330, -1, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					linear15.setLayoutParams(lp);
				}
menulayout.addView(linear15);

		linear17 = new LinearLayout(context);
				{
					linear17.setOrientation(1);
					linear17.setPadding(5, 5, 5, 5);
					linear17.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(-886445);
					design.setCornerRadii(new float[] { 10.0f, 10.0f, 10.0f, 10.0f, 10.0f, 10.0f, 10.0f, 10.0f });
					design.setStroke(1, -886445);
					linear17.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, 13, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					linear17.setLayoutParams(lp);
				}
linear15.addView(linear17);

		linear18 = new LinearLayout(context);
				{
					linear18.setOrientation(0);
					linear18.setPadding(5, 5, 5, 5);
					linear18.setGravity(17);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16777216);
					linear18.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, -2, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 10;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					linear18.setLayoutParams(lp);
				}
linear15.addView(linear18);

		imageview21 = new ImageView(context);
				{
					imageview21.setPadding(5, 5, 5, 5);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16776961);
					imageview21.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, 137, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					imageview21.setLayoutParams(lp);
					
					Utils.SetAssets(context, imageview21, "icon.png");
				}
linear18.addView(imageview21);

		_pages = new LinearLayout(context);
				{
					_pages.setOrientation(1);
					_pages.setPadding(5, 5, 5, 5);
					_pages.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, 1441954131);
					_pages.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, 550, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 10;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					_pages.setLayoutParams(lp);
				}
linear15.addView(_pages);

		_close = new LinearLayout(context);
				{
					_close.setOrientation(0);
					_close.setPadding(5, 5, 5, 5);
					_close.setGravity(17);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16777216);
					_close.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, -2, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 5;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					_close.setLayoutParams(lp);
				}
linear15.addView(_close);

		textview22 = new TextView(context);
				{
					textview22.setText("Close");
					textview22.setPadding(5, 5, 5, 5);
					textview22.setGravity(17);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(1, 0);
					textview22.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-2, -2, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					textview22.setLayoutParams(lp);
					textview22.setTextColor(-1);
					textview22.setTextSize(13.0f);
					textview22.setTypeface(Utils.font(context));
				}
_close.addView(textview22);

		linear16 = new LinearLayout(context);
				{
					linear16.setOrientation(1);
					linear16.setPadding(5, 5, 5, 5);
					linear16.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(-1);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(1, -16777216);
					linear16.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, -1, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					linear16.setLayoutParams(lp);
				}
menulayout.addView(linear16);

		linear23 = new LinearLayout(context);
				{
					linear23.setOrientation(1);
					linear23.setPadding(5, 5, 5, 5);
					linear23.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(-886445);
					design.setCornerRadii(new float[] { 10.0f, 10.0f, 10.0f, 10.0f, 10.0f, 10.0f, 10.0f, 10.0f });
					design.setStroke(1, -886445);
					linear23.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, 13, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					linear23.setLayoutParams(lp);
				}
linear16.addView(linear23);

		_underpages = new LinearLayout(context);
				{
					_underpages.setOrientation(0);
					_underpages.setPadding(5, 5, 5, 5);
					_underpages.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16777216);
					_underpages.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, 82, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 10;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					_underpages.setLayoutParams(lp);
				}
linear16.addView(_underpages);

		_scroll = new LinearLayout(context);
				{
					_scroll.setOrientation(0);
					_scroll.setPadding(5, 5, 5, 5);
					_scroll.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16777216);
					_scroll.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, -1, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 5;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					_scroll.setLayoutParams(lp);
				}
linear16.addView(_scroll);
TextView _pagetitle = new TextView(context);

ImageView _pagesrc = new ImageView(context);
		
		__pagetitle = _pagetitle;
		__pagesrc = _pagesrc;
		
		_close.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				hideMenu();
			}
		});
		
		__scroll = new ScrollView(context);
		__scroll.setFillViewport(true);
		
		__page = new LinearLayout(context);
		__page.setOrientation(LinearLayout.VERTICAL);
		
		__scroll.addView(__page, -1, -1);
		_scroll.addView(__scroll, -1, -1);
		
		hideMenu();
		wmManager.addView(_parentBox, wmParams);
	}
	
	View.OnTouchListener handleMotionTouch = new View.OnTouchListener()
	{
		private float initX;          
		private float initY;
		private float touchX;
		private float touchY;

		double clock=0;
		
		@Override
		public boolean onTouch(View vw, MotionEvent ev)
		{

			switch (ev.getAction())
			{
				case MotionEvent.ACTION_DOWN:

					initX = wmParams.x;
					initY = wmParams.y;
					touchX = ev.getRawX();
					touchY = ev.getRawY();
					clock = System.currentTimeMillis();
					break;

				case MotionEvent.ACTION_MOVE:
					wmParams.x = (int)initX + (int)(ev.getRawX() - touchX);

					wmParams.y = (int)initY + (int)(ev.getRawY() - touchY);


					wmManager.updateViewLayout(vw, wmParams);
					break;

				case MotionEvent.ACTION_UP:
					if (!_isShow && (System.currentTimeMillis() < (clock + 200)))
					{
						showMenu();
					}
					break;
			}
			return true;
		}
	};
}
