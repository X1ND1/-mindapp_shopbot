package il2cpp.typefaces;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import il2cpp.Utils;
import android.widget.ImageView;

public class UnderPageButton extends LinearLayout {
	Context context;
	
	public static interface Callback {
		public void onClick();
	}
	public Callback callback;
	View __isopen;
	
	
TextView _pagetitle;

	public void show() {
		__isopen.setVisibility(View.VISIBLE);
	}
	
	public void hide() {
		__isopen.setVisibility(View.GONE);
	}
	
	public void anim() {
		Utils.anim(this, 400);
	}
	
	public UnderPageButton(Context context, String __text, String __src) {
		super(context);
		this.context = context;
		
		
		
				{
					this.setOrientation(1);
					this.setPadding(5, 5, 5, 5);
					this.setGravity(17);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16777216);
					this.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-2, -2, 0);
					lp.leftMargin   = 30;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					this.setLayoutParams(lp);
				}


		_pagetitle = new TextView(context);
				{
					_pagetitle.setText("TextView");
					_pagetitle.setPadding(5, 5, 5, 5);
					_pagetitle.setGravity(17);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16777216);
					_pagetitle.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-2, -2, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					_pagetitle.setLayoutParams(lp);
					_pagetitle.setTextColor(-886445);
					_pagetitle.setTextSize(10.0f);
					_pagetitle.setTypeface(Utils.font(context));
				}
this.addView(_pagetitle);
LinearLayout _isopen = new LinearLayout(context);

ImageView _pagesrc = new ImageView(context);

		
		__isopen = _isopen;
		
		this.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				anim();
				if (callback != null) callback.onClick();
			}
		});
		_pagetitle.setText(__text);
		Utils.SetAssets(context, _pagesrc, __src);
	}
}
